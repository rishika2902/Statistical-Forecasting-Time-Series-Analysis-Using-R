#Part1 ARIMA 

library(Mcomp)
a <- M3[[1389]]
a
plot(a)
a$x
a <- a$x
plot(a)

tsdisplay(a)
## In the below codes we will be applying first order differencing and second order differencing 

#for removing trends
diffa <- diff(a, lag=1)
tsdisplay(diffa)

#for removing seasonal spikes
diff4diffa <- diff(diffa, lag=4)
tsdisplay(diff4diffa)

# I want to see that my data is stationary or not. So, I will be testing it. 
library(tseries)
adf.test(diff4diffa)
#low p-value in the console indicates that the data is indeed stationary.
kpss.test(diff4diffa) #high p-value meaning data is not stationary.
#to be clear: the null hypothesis is diff between these two tests. 
# so, now I finally made my data staionary. 

# ARIMA(0,1,1)(0,1,1)[4]
# ARIMA(1,1,1)(0,1,1)[4]

fit1 <- arima(a, order=c(0,1,1), seasonal=c(0,1,1))
summary(fit1)

fit2 <- arima(a, order=c(1,1,1), seasonal=c(0,1,1))
summary(fit2)

#creating another model fit3, fit3, fit4, fit5, fit6 by changing the fit1 by 1 

fit3 <- arima(a, order=c(2,1,1), seasonal=c(0,1,2))
summary(fit3)

fit4 <- arima(a, order=c(1,1,2), seasonal=c(0,1,2))
summary(fit4)

fit5 <- arima(a, order=c(1,1,1), seasonal=c(1,1,1))
summary(fit5)

fit6 <- arima(a, order=c(2,1,1), seasonal=c(0,1,1))
summary(fit6)

fit7 <- arima(a, order=c(1,1,2), seasonal=c(0,1,1))
summary(fit7)

fit8 <- arima(a, order=c(1,1,1), seasonal=c(0,1,2))
summary(fit8)

fit9 <- arima(a, order=c(2,1,1), seasonal=c(0,1,2))
summary(fit9)

fit10 <- arima(a, order=c(2,1,1), seasonal=c(1,1,2))
summary(fit10)

fit11 <- arima(a, order=c(1,1,2), seasonal=c(1,1,2))
summary(fit11)

fit12 <- arima(a, order=c(3,1,3), seasonal=c(0,1,1))
summary(fit12)

fit13 <- arima(a, order=c(3,1,3), seasonal=c(0,1,3))
summary(fit13)

fit14 <- arima(a, order=c(0,1,3), seasonal=c(0,1,3))
summary(fit14)

fit15 <- arima(a, order=c(0,1,3), seasonal=c(0,1,1))
summary(fit15)

fit16 <- arima(a, order=c(0,1,1), seasonal=c(0,1,3))
summary(fit16)

fit17 <- arima(a, order=c(1,1,3), seasonal=c(0,1,1))
summary(fit17)

fit18 <- arima(a, order=c(3,1,1), seasonal=c(0,1,1))
summary(fit18)

library(forecast)

tsdisplay(residuals(fit15))
checkresiduals(fit15)
fitdf <- summary(fit15)$df.residual
print(fitdf)
Box.test(residuals(fit15), lag=16, fitdf=4) #p-value is quite high so it's a good fit

forecast(fit15, level=c(80, 90, 95, 99))
plot(forecast(fit15, h=8))
------------------------------------------------------------------------
