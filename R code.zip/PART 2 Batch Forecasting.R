library(forecast)
library(Mcomp)
library(tidyverse)

# Define the series IDs as per your student ID (last digit corresponds to these)
d <- seq(from = 700 + 5, to = 1400, by = 10)

# Create empty lists to store time series and descriptions
time_series_list <- list()
descrip <- list()

# Populate the lists with series data and their descriptions
for (id in d) {
  time_series_list[[as.character(id)]] <- M3[[id]]
  descrip[[as.character(id)]] <- M3[[id]]$description
}

d
# Forecast horizon (8 periods for out-of-sample data)
forecast_horizon <- 8

# Create a list to store the results
forecast_results <- list()

# Loop over each time series to generate forecasts
for (id in d) {
  # Get the current series from time_series_list
  series_data <- time_series_list[[as.character(id)]]$x  # The in-sample time series data
  
  # Define the in-sample and out-of-sample data
  train_length <- length(series_data) - forecast_horizon
  training_set <- series_data[1:train_length]
  validation_set <- series_data[(train_length + 1):(train_length + forecast_horizon)]
  
  # Fit the ETS model
  ets_model <- ets(training_set)
  ets_forecast <- forecast(ets_model, h = forecast_horizon)
  
  # Fit the ARIMA model
  arima_model <- auto.arima(training_set)
  arima_forecast <- forecast(arima_model, h = forecast_horizon)
  
  # Evaluate models using RMSE, MAE, and MAPE
  ets_rmse <- sqrt(mean((validation_set - ets_forecast$mean)^2))
  arima_rmse <- sqrt(mean((validation_set - arima_forecast$mean)^2))
  
  ets_mae <- mean(abs(validation_set - ets_forecast$mean))
  arima_mae <- mean(abs(validation_set - arima_forecast$mean))
  
  ets_mape <- mean(abs((validation_set - ets_forecast$mean) / validation_set)) * 100
  arima_mape <- mean(abs((validation_set - arima_forecast$mean) / validation_set)) * 100
  
  # Select the best model based on RMSE, MAE, and MAPE
  if (ets_rmse < arima_rmse && ets_mae < arima_mae && ets_mape < arima_mape) {
    best_model <- "ETS"
    final_forecast <- ets_forecast
  } else {
    best_model <- "ARIMA"
    final_forecast <- arima_forecast
  }
  
  # Store results for this series
  forecast_results[[as.character(id)]] <- list(
    model = best_model,
    forecast = final_forecast$mean,
    lower80 = final_forecast$lower[,1],
    upper80 = final_forecast$upper[,1],
    lower95 = if (ncol(final_forecast$lower) >= 2) final_forecast$lower[,2] else NA,
    upper95 = if (ncol(final_forecast$upper) >= 2) final_forecast$upper[,2] else NA,
    lower99 = if (ncol(final_forecast$lower) >= 3) final_forecast$lower[,3] else NA,
    upper99 = if (ncol(final_forecast$upper) >= 3) final_forecast$upper[,3] else NA
  )
}

# Create a summary dataframe for results
results_df <- data.frame(
  series_id = rep(d, each = forecast_horizon),  # Repeat series_id for each forecast period
  forecast = unlist(lapply(forecast_results, function(x) x$forecast)),
  lower80 = unlist(lapply(forecast_results, function(x) x$lower80)),
  upper80 = unlist(lapply(forecast_results, function(x) x$upper80)),
  lower95 = unlist(lapply(forecast_results, function(x) x$lower95)),
  upper95 = unlist(lapply(forecast_results, function(x) x$upper95)),
  lower99 = unlist(lapply(forecast_results, function(x) x$lower99)),
  upper99 = unlist(lapply(forecast_results, function(x) x$upper99)),
  model = rep(unlist(lapply(forecast_results, function(x) x$model)), each = forecast_horizon)
)

# Print results summary
print(head(results_df))  # Preview the first few rows


# Libraries for forecasting
library(forecast)
library(tidyverse)

# Assuming 'forecast_results' contains the best forecasts for each series based on validation set
# And 'time_series_list' contains the time series data

# Define the forecast horizon (8 periods out-of-sample)
forecast_horizon <- 8

# Create a list to store the benchmark results
benchmark_results <- list()

# Loop through each time series for evaluation
for (id in d) {
  
  # Get the time series data
  series_data <- time_series_list[[as.character(id)]]$x
  train_length <- length(series_data) - forecast_horizon
  training_set <- series_data[1:train_length]
  validation_set <- series_data[(train_length + 1):(train_length + forecast_horizon)]
  
  # ETS forecast (from the final selected model)
  ets_forecast <- forecast(ets(training_set), h = forecast_horizon)
  
  # ARIMA forecast (from the final selected model)
  arima_forecast <- forecast(auto.arima(training_set), h = forecast_horizon)
  
  # Naive forecast (benchmark 1)
  naive_forecast <- rep(tail(training_set, 1), forecast_horizon)
  
  # Damped Exponential Smoothing (benchmark 2)
  damped_forecast <- forecast(ets(training_set, damped = TRUE), h = forecast_horizon)
  
  # Simple Exponential Smoothing (benchmark 3)
  ses_forecast <- forecast(ets(training_set, model = "ANN"), h = forecast_horizon)
  
  # Calculate RMSE, MAE, MAPE for ETS model
  ets_rmse <- sqrt(mean((validation_set - ets_forecast$mean)^2))
  ets_mae <- mean(abs(validation_set - ets_forecast$mean))
  ets_mape <- mean(abs((validation_set - ets_forecast$mean) / validation_set)) * 100
  
  # Calculate RMSE, MAE, MAPE for ARIMA model
  arima_rmse <- sqrt(mean((validation_set - arima_forecast$mean)^2))
  arima_mae <- mean(abs(validation_set - arima_forecast$mean))
  arima_mape <- mean(abs((validation_set - arima_forecast$mean) / validation_set)) * 100
  
  # Calculate RMSE, MAE, MAPE for Naive model
  naive_rmse <- sqrt(mean((validation_set - naive_forecast)^2))
  naive_mae <- mean(abs(validation_set - naive_forecast))
  naive_mape <- mean(abs((validation_set - naive_forecast) / validation_set)) * 100
  
  # Calculate RMSE, MAE, MAPE for Damped Exponential Smoothing model
  damped_rmse <- sqrt(mean((validation_set - damped_forecast$mean)^2))
  damped_mae <- mean(abs(validation_set - damped_forecast$mean))
  damped_mape <- mean(abs((validation_set - damped_forecast$mean) / validation_set)) * 100
  
  # Calculate RMSE, MAE, MAPE for Simple Exponential Smoothing model
  ses_rmse <- sqrt(mean((validation_set - ses_forecast$mean)^2))
  ses_mae <- mean(abs(validation_set - ses_forecast$mean))
  ses_mape <- mean(abs((validation_set - ses_forecast$mean) / validation_set)) * 100
  
  # Store all evaluation metrics for comparison
  benchmark_results[[as.character(id)]] <- data.frame(
    Model = c("ETS", "ARIMA", "Naive", "Damped ETS", "Simple ETS"),
    RMSE = c(ets_rmse, arima_rmse, naive_rmse, damped_rmse, ses_rmse),
    MAE = c(ets_mae, arima_mae, naive_mae, damped_mae, ses_mae),
    MAPE = c(ets_mape, arima_mape, naive_mape, damped_mape, ses_mape)
  )
}

# Combine all benchmark results into one data frame
benchmark_summary <- do.call(rbind, benchmark_results)

# Display the summary of evaluation metrics for each series and model
print(benchmark_summary)

# Now, let's calculate the average error metrics across all series for each model
average_errors <- benchmark_summary %>%
  group_by(Model) %>%
  summarise(
    Avg_RMSE = mean(RMSE),
    Avg_MAE = mean(MAE),
    Avg_MAPE = mean(MAPE)
  )

# Print the average error metrics
print(average_errors)

# Identify the best-performing model based on the minimum RMSE, MAE, or MAPE
best_model_rmse <- average_errors[which.min(average_errors$Avg_RMSE),]
best_model_mae <- average_errors[which.min(average_errors$Avg_MAE),]
best_model_mape <- average_errors[which.min(average_errors$Avg_MAPE),]

cat("Best model based on RMSE: ", best_model_rmse$Model, "\n")
cat("Best model based on MAE: ", best_model_mae$Model, "\n")
cat("Best model based on MAPE: ", best_model_mape$Model, "\n")


library(ggplot2)

# Create a plotting function to visualize forecasts
plot_forecasts <- function(series_id, training_set, forecast_results) {
  forecast_data <- forecast_results[[as.character(series_id)]]
  
  # Create a data frame for plotting
  plot_data <- data.frame(
    Time = c(1:length(training_set), forecast_data$Time),
    Value = c(training_set, forecast_data$ETS),
    Model = rep("ETS", length(training_set) + length(forecast_data$Time))
  )
  
  # Add other models to the plot data
  plot_data <- rbind(
    plot_data,
    data.frame(
      Time = c(1:length(training_set), forecast_data$Time),
      Value = c(training_set, forecast_data$ARIMA),
      Model = rep("ARIMA", length(training_set) + length(forecast_data$Time))
    ),
    data.frame(
      Time = c(1:length(training_set), forecast_data$Time),
      Value = c(training_set, forecast_data$Naive),
      Model = rep("Naive", length(training_set) + length(forecast_data$Time))
    ),
    data.frame(
      Time = c(1:length(training_set), forecast_data$Time),
      Value = c(training_set, forecast_data$Damped_ETS),
      Model = rep("Damped ETS", length(training_set) + length(forecast_data$Time))
    ),
    data.frame(
      Time = c(1:length(training_set), forecast_data$Time),
      Value = c(training_set, forecast_data$Simple_ETS),
      Model = rep("Simple ETS", length(training_set) + length(forecast_data$Time))
    )
  )
  
  # Plot the data
  ggplot(plot_data, aes(x = Time, y = Value, color = Model)) +
    geom_line() +
    geom_point(data = plot_data[plot_data$Time > length(training_set), ], aes(x = Time, y = Value), size = 3) +
    labs(title = paste("Forecasting for Time Series ID:", series_id),
         x = "Time",
         y = "Value") +
    theme_minimal() +
    scale_color_manual(values = c("blue", "red", "green", "purple", "orange"))
}

# Plot the forecast for the first time series in the list
plot_forecasts(d[2], time_series_list[[as.character(d[2])]]$x, forecast_results)

# If you want to plot for all series, you can loop through them
for (id in d) {
  plot_forecasts(id, time_series_list[[as.character(id)]]$x, forecast_results)
}

library(forecast)

# Error calculation functions
calculate_errors <- function(actual, forecast) {
  # Ensure both actual and forecast are numeric vectors of the same length
  actual <- as.numeric(actual)
  forecast <- as.numeric(forecast)
  
  # Calculate the error metrics
  mae <- mean(abs(actual - forecast))
  mse <- mean((actual - forecast)^2)
  rmse <- sqrt(mse)
  
  return(data.frame(MAE = mae, MSE = mse, RMSE = rmse))
}

# Define benchmark models and errors calculation
evaluate_model <- function(training_data, test_data, forecast_results, model_type) {
  
  # Forecast using different models (ETS, ARIMA, Naive, etc.)
  if(model_type == "ETS") {
    forecast_model <- ets(training_data)
    forecast_data <- forecast(forecast_model, h = length(test_data))
  } else if(model_type == "ARIMA") {
    forecast_model <- auto.arima(training_data)
    forecast_data <- forecast(forecast_model, h = length(test_data))
  } else if(model_type == "Naive") {
    forecast_data <- naive(training_data, h = length(test_data))
  } else if(model_type == "Damped ETS") {
    forecast_model <- ets(training_data, damped = TRUE)
    forecast_data <- forecast(forecast_model, h = length(test_data))
  } else if(model_type == "Seasonal Naive") {
    forecast_data <- snaive(training_data, h = length(test_data))
  }
  
  # Calculate errors between actual and forecasted values
  errors <- calculate_errors(test_data, forecast_data$mean)
  return(errors)
}

# Run evaluation for all models
all_errors <- data.frame()

for (id in d) {
  
  # Extract training and test data
  training_data <- time_series_list[[as.character(id)]]$x
  test_data <- time_series_list[[as.character(id)]]$xx
  
  # Evaluate each model and save the results
  ets_errors <- evaluate_model(training_data, test_data, forecast_results, "ETS")
  arima_errors <- evaluate_model(training_data, test_data, forecast_results, "ARIMA")
  naive_errors <- evaluate_model(training_data, test_data, forecast_results, "Naive")
  damped_ets_errors <- evaluate_model(training_data, test_data, forecast_results, "Damped ETS")
  seasonal_naive_errors <- evaluate_model(training_data, test_data, forecast_results, "Seasonal Naive")
  
  # Combine all errors into one data frame
  model_errors <- cbind(
    SeriesID = id,
    ETS = ets_errors,
    ARIMA = arima_errors,
    Naive = naive_errors,
    DampedETS = damped_ets_errors,
    SeasonalNaive = seasonal_naive_errors
  )
  
  all_errors <- rbind(all_errors, model_errors)
}



# Analyze errors across horizons (1-4, 5-6, 7-8 periods)
error_by_horizon <- all_errors %>%
  gather(key = "Model", value = "Error", -SeriesID) %>%
  mutate(Horizon = case_when(
    SeriesID %% 3 == 1 ~ "Short-term",
    SeriesID %% 3 == 2 ~ "Medium-term",
    TRUE ~ "Long-term"
  ))

# Compare and discuss the models
ggplot(error_by_horizon, aes(x = Horizon, y = Error, color = Model, group = Model)) +
  geom_line() + 
  geom_point() + 
  labs(title = "Forecast Error Comparison Across Horizons",
       x = "Horizon",
       y = "Error Metric (MAE, MSE, RMSE)") +
  theme_minimal()

# Load necessary libraries
library(forecast)
library(tidyverse)

# Function to calculate errors: MAE, MSE, RMSE
calculate_errors <- function(actual, forecast) {
  mae <- mean(abs(actual - forecast))
  mse <- mean((actual - forecast)^2)
  rmse <- sqrt(mse)
  return(data.frame(MAE = mae, MSE = mse, RMSE = rmse))
}

# Cross-validation function for time series
cross_validate <- function(time_series, model_type, train_size, forecast_horizon, step_size) {
  errors_list <- list()
  
  # Number of validation splits
  n_splits <- length(time_series) - train_size - forecast_horizon + 1
  
  # Inner loop: Rolling-window cross-validation
  for (i in 1:n_splits) {
    # Create training and validation sets
    train_set <- time_series[i:(i + train_size - 1)]
    test_set <- time_series[(i + train_size):(i + train_size + forecast_horizon - 1)]
    
    # Fit the selected model
    tryCatch({
      if (model_type == "ETS") {
        model <- ets(train_set)
        forecast_data <- forecast(model, h = forecast_horizon)
      } else if (model_type == "ARIMA") {
        model <- auto.arima(train_set)
        forecast_data <- forecast(model, h = forecast_horizon)
      } else {
        stop("Model type not recognized.")
      }
      
      # Calculate the error for this fold
      errors <- calculate_errors(test_set, forecast_data$mean)
      errors_list[[i]] <- errors
    }, error = function(e) {
      message("Error in model fitting or forecasting for time series ", i)
    })
  }
  
  # Return a data frame of errors for each fold of cross-validation
  return(do.call(rbind, errors_list))
}

# Model selection function for batch forecasting using cross-validation
batch_forecasting <- function(time_series_data, series_ids, train_size, forecast_horizon, step_size) {
  
  all_errors <- data.frame()  # Data frame to store all errors
  
  # Outer loop: Iterate over each time series
  for (id in d) {
    time_series <- time_series_data[[as.character(id)]]$x  # Extract time series data
    
    # Cross-validation for ETS model
    ets_errors <- cross_validate(time_series, model_type = "ETS", 
                                 train_size = train_size, forecast_horizon = forecast_horizon, step_size = step_size)
    
    # Cross-validation for ARIMA model
    arima_errors <- cross_validate(time_series, model_type = "ARIMA", 
                                   train_size = train_size, forecast_horizon = forecast_horizon, step_size = step_size)
    
    # Store errors for comparison (averaged over all cross-validation folds)
    model_comparison <- data.frame(SeriesID = rep(id, 2),
                                   Model = c("ETS", "ARIMA"),
                                   MAE = c(mean(ets_errors$MAE), mean(arima_errors$MAE)),
                                   MSE = c(mean(ets_errors$MSE), mean(arima_errors$MSE)),
                                   RMSE = c(mean(ets_errors$RMSE), mean(arima_errors$RMSE)))
    
    # Add the comparison results for this series to the overall results
    all_errors <- rbind(all_errors, model_comparison)
  }
  
  return(all_errors)
}

# Example usage:
series_ids <- seq(from = 700+5, to = 1400, by = 10)  # Modify this based on your actual dataset
time_series_data <- list()  # Replace with your dataset (e.g., M3 dataset)

# Cross-validation parameters
train_size <- 36  # Training set size (e.g., last 36 months of data)
forecast_horizon <- 8  # Forecasting for 8 quarters ahead (adjust as needed)
step_size <- 1  # Step size for rolling window (1 means each validation set slides forward 1 period)

# Perform batch forecasting and model comparison
model_comparison_results <- batch_forecasting(time_series_data, series_ids, train_size, forecast_horizon, step_size)

# View the results
print(model_comparison_results)

# Plot the results (e.g., RMSE comparison across time series)
ggplot(model_comparison_results, aes(x = SeriesID, y = RMSE, color = Model)) +
  geom_line() +
  geom_point() +
  labs(title = "Model Comparison (ETS vs ARIMA) Across Time Series",
       x = "Series ID",
       y = "Root Mean Squared Error (RMSE)") +
  theme_minimal()