#PART 1 -- Regression Model

library(Mcomp)
y <- M3[[1389]]
y

#DATA EXPLORATION

y$h #horizon
y$n

y$description 
plot(y, main= "Time Series for 1389", ylab="Values", xlab= "Quarter")


y <- y$x #insample data
y
plot(y, main = "Insample Time Series for 1389", ylab = "Values", xlab = "Year", col = "blue", lwd = 2, type="o")

#Descriptive Statistics 
summary(y)

#Outlier
boxplot(y, main = "Outliers Detection", ylab = "Values")
iqr_value <- IQR(y)
upper_bound <- quantile(y, 0.75) + 1.5 * iqr_value #upper bound for outliers
outlier_index <- which(y > upper_bound)
outlier_period <- time(y)[outlier_index]

#Detailled statistics
library(moments)             

mean(y)      
sd(y)         
skewness(y)   
kurtosis(y)   

library(forecast)
library(ggplot2)

#Seasonal Plot and Subseries Plot
ggseasonplot(y) + 
  ggtitle("Seasonal Plot: Total Job Offered-Netherlands") +
  xlab("Quarter") + 
  ylab("Values")

ggsubseriesplot(y) + 
  ggtitle("Seasonalsubseries Plot: Total Job Offered-Netherlands") + 
  xlab("Quarter") + 
  ylab("Values")

#POLAR

ggseasonplot(y, polar = TRUE) + 
  ggtitle("Polar Seasonal Plot: Total Jobs Offered-Netherlands") + 
  xlab("Quarter") + 
  ylab("Values")

#Decomposition

#Additive
dy1 <- decompose(y)
plot(dy1)

dy1$trend #Trend component
dy1$seasonal #seasonal component 

#Multiplicative decomposition
dy2 <- decompose(y, type = "multiplicative") 
plot(dy2)
dy2$seasonal

#STL
lambda = BoxCox.lambda(y, lower=0, upper=1)
by = BoxCox(y, lambda)
dy = stl(by, t.window=10, s.window=5)
plot(dy)

#Regression Modelling, Analysis and Forecasting 
trend <- 1:length(y)
trend

library(forecast)

fit1 <- tslm(y ~ trend)
plot(y, main="Trend", xlab="Quarter", ylab="Values")
lines(fit1$fitted.values, col="red")
summary(fit1)
checkresiduals(fit1)

fit2 <- tslm(y ~ trend + season)
plot(y, main="Trend and Seasonality",xlab="Quarter", ylab="Values")
lines(fit2$fitted.values, col="red")
summary(fit2)
checkresiduals(fit2)

fit3 <- tslm(y ~ trend * season)
plot(y, main="Trend and Seasonality Interaction",xlab="Quarter", ylab="Values")
lines(fit3$fitted.values, col="red")
summary(fit3)
checkresiduals(fit3)

#sqrt
fit4 <- tslm(sqrt(y) ~ trend + season)
plot(y, main ="Sqrt: Trend + Season", xlab="Quarter", ylab="Values")
lines((fit4$fitted.values)^2, col="red")
summary(fit4)
checkresiduals(fit4)

fit5 <- tslm(sqrt(y) ~ trend)
plot(y, main ="Sqrt: Trend",xlab="Quarter", ylab="Values")
lines((fit5$fitted.values)^2, col="red")
summary(fit5)
checkresiduals(fit5)

fit6 <- tslm(sqrt(y) ~ trend * season)
plot(y, main="Sqrt: Trend * Season",xlab="Quarter", ylab="Values" )
lines((fit6$fitted.values)^2, col="red")
summary(fit6)
checkresiduals(fit6)

#logarithmic
fit7log <- tslm(log(y) ~ trend)
plot(y, main="Logarithmic Transformation",xlab="Quarter", ylab="Values"  )
lines(exp(fit7log$fitted.values), col="red")
summary(fit7log)
checkresiduals(fit7log)

fit8log <- tslm(log(y) ~ trend + season)
plot(y, main="Log: Trend+Season", xlab="Quarter", ylab="Values")
lines(exp(fit8log$fitted.values), col="red")
summary(fit8log)
checkresiduals(fit8log)

fit9log <- tslm(log(y) ~ trend * season)
plot(y, main= "Log:Trend*Season", xlab="Quarter", ylab="Values")
lines(exp(fit9log$fitted.values), col="red")
summary(fit9log)
checkresiduals(fit9log)

#Polynomial 
fit10 <- tslm(y ~ trend + I(trend^2))
plot(y,main = "Polynomial Transformation: Trend", xlab="Quarter", ylab="Values")
lines(fit10$fitted.values, col="red")
summary(fit10)
checkresiduals(fit10)

fit11 <- tslm(y ~ trend + season + I(trend^2))
plot(y, main = "Polynomial Transformation: Trend + Season", xlab="Quarter", ylab="Values")
lines(fit11$fitted.values, col="red")
summary(fit11)
checkresiduals(fit11)

fit12 <- tslm(y ~ trend * season + I(trend^2))
plot(y, main = "Polynomial Transformation: Trend*Season", xlab="Quarter", ylab="Values")
lines(fit12$fitted.values, col="red")
summary(fit12)
checkresiduals(fit12)

#forecasting fit 11 as the best model

forecast_fit11 <- forecast(fit11, h = 8, level = c(0.8, 0.9, 0.95, 0.99))
forecast_fit11

plot(forecast_fit11, main = "Regression Model", 
     xlab = "Time", ylab = "y", 
     col = "blue")

checkresiduals(fit11)
-------------------------------------------------------------------------
