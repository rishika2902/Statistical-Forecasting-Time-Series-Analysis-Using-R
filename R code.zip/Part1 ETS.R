#Week 7 ets MODEL- DONE only decomposition is left. 

library(Mcomp)

z <- M3[[1389]]
z

plot(z)

z <- z$x
z
plot(z, type="o")


#Exponential Smoothing Modelling, Analysis and Forecasting

fit <- ets(z, model="ANN") 
summary(fit1)
forecast(fit1, h=8)
#creating forecast for three confidence levels:
plot(forecast(fit1, h=8, level = c(0.9, 0.95, 0.99)))

plot(z, xlim=c(1959, 1970+3/4))
lines(forecast(fit1, h=8)$mean, col="blue") #used mean to see any point forecast without any prediction interval
legend("topleft", c("Historical Data", "ETS(ANN)"), col=c("Red", "Blue"), lwd = c(2,2))

library(magrittr)
library(ggplot2)
library(forecast)


#Holt's linear Trend 
fit2 <- ets(z, model="AAN", damped=FALSE) #This is basically AADN model. D here is damped, which is used to make sure that it is holt's winter linear trend. 
summary(fit2)

#this model captures the trend but not the seasonality so this is the iterative model
plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)"), col=c("Black", "Blue", "Red"), lwd = c(2,2,2))

#A more complicated model. (non-linear trend)
fit3 <- ets(z, model="AAN", damped=TRUE)
summary(fit3)

plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
lines(forecast(fit3, h=8)$mean, col= "green")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)", "ETS(AAdN)" ), col=c("Black", "Blue", "Red", "Green"), lwd = c(2,2,2,2))

#Holt's Winter model
#this has both trend and seasonality
fit4 <- ets(z, model="AAA", damped=FALSE)
summary(fit4)

plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
lines(forecast(fit3, h=8)$mean, col= "green")
lines(forecast(fit4, h=8)$mean, col= "orange")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)", "ETS(AAdN)", "ETS(AAA)"), col=c("Black", "Blue", "Red", "Green", "Orange"), lwd = c(2,2,2,2,2))

fit5 <- ets(z, model="AAA", damped=TRUE)
summary(fit5)

plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
lines(forecast(fit3, h=8)$mean, col= "green")
lines(forecast(fit4, h=8)$mean, col= "orange")
lines(forecast(fit5, h=8)$mean, col= "purple")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)", "ETS(AAdN)", "ETS(AAA)", "ETS(AAdA)"), col=c("Black", "Blue", "Red", "Green", "Orange", "Purple"), lwd = c(2,2,2,2,2,2))

fit6 <- ets(z, model="MAM", damped=FALSE)
summary(fit6)

plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
lines(forecast(fit3, h=8)$mean, col= "green")
lines(forecast(fit4, h=8)$mean, col= "orange")
lines(forecast(fit5, h=8)$mean, col= "purple")
lines(forecast(fit6, h=8)$mean, col= "skyblue")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)", "ETS(AAdN)", "ETS(AAA)", "ETS(AAdA)", "ETS(MAM)"), col=c("Black", "Blue", "Red", "Green", "Orange", "Purple", "Skyblue"), lwd = c(2,2,2,2,2,2,2))
       

fit7 <- ets(z, model="MAM", damped=TRUE)
summary(fit7)

plot(z, xlim=c(1959, 1970+3/4), ylim=c(100, 7500))
lines(forecast(fit1, h=8)$mean, col="blue") 
lines(forecast(fit2, h=8)$mean, col= "red")
lines(forecast(fit3, h=8)$mean, col= "green")
lines(forecast(fit4, h=8)$mean, col= "orange")
lines(forecast(fit5, h=8)$mean, col= "purple")
lines(forecast(fit6, h=8)$mean, col= "skyblue")
lines(forecast(fit7, h=8)$mean, col= "brown")
legend("topleft", c("Historical Data", "ETS(ANN)", "ETS(AAN)", "ETS(AAdN)", "ETS(AAA)", "ETS(AAdA)", "ETS(MAM)", "ETS(MAM)"), col=c("Black", "Blue", "Red", "Green", "Orange", "Purple", "Skyblue"), lwd = c(2,2,2,2,2,2,2))

plot(forecast(fit5, h=8, level = c(0.8, 0.9, 0.95, 0.99)))

checkresiduals(fit5)

-------------------------------------------------------------------
